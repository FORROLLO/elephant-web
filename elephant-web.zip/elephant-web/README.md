# Elephant (PWA) — desplegar en Cloudflare Pages

Es un sitio estático puro (HTML/CSS/JS), no necesita build ni compilación.

## Subirlo a Cloudflare Pages (sin usar Git)

1. Entra a [dash.cloudflare.com](https://dash.cloudflare.com) → **Workers & Pages** → **Create** → **Pages** → **Upload assets**.
2. Ponle un nombre al proyecto (ej. `elephant`).
3. Arrastra **todos los archivos de esta carpeta** (`index.html`, `styles.css`, `app.js`, `manifest.json`, `sw.js`, la carpeta `icons/`) — no la carpeta contenedora, sino su contenido.
4. Deploy. Te da una URL tipo `elephant.pages.dev`.

## Instalarlo como app en tu Android

1. Abre esa URL en Chrome desde tu celular.
2. Menú (⋮) → **"Agregar a pantalla de inicio"** o **"Instalar app"**.
3. Queda con ícono propio, se abre sin barra del navegador, como una app nativa.

## Qué funciona igual (o mejor) que la idea original

- Cada imagen y video de la página muestra su propio botón de descarga (ver sección de abajo) — ya no depende de que pegues la URL a mano.
- El archivo se guarda en **IndexedDB** (almacenamiento privado del sitio, invisible fuera de la app). Solo al tocar "Guardar al dispositivo" se dispara una descarga real del navegador, que va a la carpeta de Descargas/Galería del sistema.
- Marcadores, historial e incógnito: guardados en `localStorage`.

## Importante al volver a desplegar

Cada vez que subas una versión nueva a Cloudflare, en tu celular entra a **Ajustes del sitio → Borrar datos** (o desinstala y reinstala la PWA) para que no se quede viendo la versión vieja guardada en caché por el service worker.

## Botón de descarga sobre cada imagen y video (nuevo)

Ahora, cuando navegas dentro de Elephant, cada `<img>` y `<video>` de la página cargada trae un botoncito de descarga en su esquina inferior. Así ves exactamente qué archivo es antes de bajarlo, en vez de confiar en un enlace escrito a mano.

**Cómo funciona por dentro:** un Cloudflare Pages Function (`functions/proxy.js`) carga la página del lado del servidor, le inserta esos botones con `HTMLRewriter`, le quita las cabeceras que normalmente impiden mostrar un sitio dentro de un iframe ajeno, y te la entrega ya lista. Al tocar el botón, la página le avisa a Elephant (`postMessage`) qué URL descargar, y otra función (`functions/fetch-media.js`) trae el archivo del lado del servidor — así también se resuelven los bloqueos de CORS que tenía la versión anterior con el campo de "pegar URL".

También se interceptan los clics en enlaces y el envío de buscadores (como la caja de búsqueda de Google) dentro de la página cargada, para que sigan pasando por el proxy en vez de navegar directo al sitio real — si no, el sitio bloquea ser embebido y verías una barra de "no se puede mostrar aquí" en vez del contenido.

**Limitaciones honestas de este enfoque de proxy:**
- Sitios muy dinámicos (aplicaciones web tipo React/Vue con su propio enrutamiento y llamadas a su API) pueden no funcionar del todo bien, porque sus propias peticiones internas quedan pensando que están en el dominio de Elephant y no en el sitio original. Para eso está el botón "↗" junto a recargar: abre el sitio real en una pestaña aparte.
- Videos que usan `<video><source src="...">` en vez de `<video src="...">` directo todavía no traen el botón (queda pendiente como mejora).
- Si el sitio define su propia política de seguridad de contenido (CSP) dentro del HTML (no solo por cabecera), en casos raros podría bloquear el botón inyectado.

## Desplegar en Cloudflare Pages (con Functions)

El proyecto ahora incluye una carpeta `functions/`, así que además de HTML/CSS/JS estático hay lógica de servidor. Dos formas de subirlo:

**Opción A — Panel web (Upload assets):** igual que antes, arrastra el contenido completo de la carpeta (incluida `functions/`) en Cloudflare Pages → Upload assets. Cloudflare detecta la carpeta `functions/` automáticamente y la publica como Pages Functions.

**Opción B — Wrangler CLI (más confiable para proyectos con Functions):**
```
npm install -g wrangler
wrangler pages deploy . --project-name=elephant
```
Ejecútalo parado dentro de la carpeta del proyecto.


Si más adelante quieres recuperar el 100% de la intercepción de descargas (cualquier botón de cualquier página, sin restricciones), eso solo se logra con la versión nativa Android que armamos antes (usa la API real de WebView del sistema operativo, que sí tiene ese permiso).
